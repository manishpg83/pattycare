export interface Params {
  [key: string]: string | number;
}
