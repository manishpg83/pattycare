#!/bin/sh

APP_PORT=$PORT node ./src/index.js